package finalproject_1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class FinalProject_1 {

    public static class horizMap extends Mapper<Object, Text, Text, DestFlightNoPojo> {

        private Text origin = new Text();
        private Text passenger = new Text();
        private DestFlightNoPojo custompojo = new DestFlightNoPojo();

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String input = new String(value.toString());
            String[] token = input.split(",");
            if (!token[0].contains("Year")) {

                origin.set(token[16]);
                // passenger.set(token[9]);
                custompojo.setDestination(token[17]);
                custompojo.setFlightNo(Integer.parseInt(token[9]));

                context.write(origin, custompojo);

            }
        }

    }

    public static class ReducerHorix extends Reducer<Text, DestFlightNoPojo, Text, Text> {

        // private LongWritable result = new LongWritable();
        private Text result = new Text();
// private Set<String> dist = new HashSet<String>();
        private List<String> dist = new ArrayList<String>();

        @Override
        protected void reduce(Text key, Iterable<DestFlightNoPojo> values, Context context) throws IOException, InterruptedException {

            String destination = "";
            Integer flightNo = 0;
            boolean flag = false;
            StringBuilder sb = new StringBuilder();

            /*
            for (Text val : values) {
                dist.add(val.toString());
            }
            for (String a : dist){
                 sb.append(a + " ");
            }
            //result.set(sb.toString());*/
            for (DestFlightNoPojo val : values) {
                destination = val.getDestination();
                flightNo = val.getFlightNo();
                //sb.append(destination+","+flightNo);

                for (String s : dist) {
                    if (s.contains(destination)) {
                        s = s + ',' + flightNo;

                        flag = true;
                    }
                }

                if (!flag) {
                    dist.add(destination + ' ' + flightNo);
                }

                flag = false;

            }

            for (String s : dist) {
                sb.append(s);
                sb.append(" ");

            }
            result.set(sb.toString());
            context.write(key, result);
            dist.clear();
        }

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        // TODO code application logic here

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Horiz1");
        job.setJarByClass(FinalProject_1.class);
        job.setMapperClass(horizMap.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DestFlightNoPojo.class);
        job.setReducerClass(ReducerHorix.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

}
