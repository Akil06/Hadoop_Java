/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_1;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;

/**
 *
 * @author akil
 */
public class DestFlightNoPojo implements Writable {
    
    String destination;
    Integer flightNo;

    public DestFlightNoPojo() {
   
        destination="";
        flightNo=0;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Integer getFlightNo() {
        return flightNo;
    }

    public void setFlightNo(Integer flightNo) {
        this.flightNo = flightNo;
    }
    
    
    
    

    @Override
    public void write(DataOutput d) throws IOException {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        d.writeInt(flightNo);
        d.writeUTF(destination);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        flightNo=di.readInt();
        destination=di.readUTF();
        
    }
    
    @Override
     public String toString()
    {
        // return (new StringBuilder().append(max_stock).append("\t").append(date_maxStock).append("\t").append(min_stock).append("\t").append(date_minStock).append("\t").append(adj).toString());
    return (new StringBuilder().append(destination).append("\t").append(flightNo).toString());
    }
    
    
}
