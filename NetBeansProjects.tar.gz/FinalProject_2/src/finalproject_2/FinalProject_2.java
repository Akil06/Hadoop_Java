/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import java.util.List;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
//import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
//import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author akil
 */
public class FinalProject_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        // TODO code application logic here
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Horiz1");
        job.setJarByClass(FinalProject_2.class);
        job.setMapperClass(DelayMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DelaysPojo.class);
        job.setReducerClass(DelayReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

    public static class DelayMapper extends Mapper<Object, Text, Text, DelaysPojo> {

        private Text origin = new Text();
        
        static int count = 0;

        private DelaysPojo custompojo = new DelaysPojo();

        @Override
        protected void map(Object key, Text value, Mapper.Context context) throws IOException, InterruptedException {
            String input = new String(value.toString());
            String[] token = input.split(",");
            count++;
            
          
            if (!token[0].trim().contains("Year")) {
                 
                origin.set(token[16]);
                // passenger.set(token[9]);
                /*if (token[24].trim().contains("NA")){
                  custompojo.setCarrierDelay(0);  
                }
                else {
                custompojo.setCarrierDelay(Integer.parseInt(token[24]));
                }
                if (token[25].trim().contains("NA")){
                  custompojo.setCarrierDelay(0);  
                }
                else {
                custompojo.setWeatherDelay(Integer.parseInt(token[25]));
                }
                if (token[26].trim().contains("NA")){
                  custompojo.setCarrierDelay(0);  
                }
                else {
                custompojo.setNasDelay(Integer.parseInt(token[26]));
                }
                if (token[27].trim().contains("NA")){
                  custompojo.setCarrierDelay(0);  
                }
                else {
                custompojo.setSecurityDelay(Integer.parseInt(token[27]));
                }
                if (token[28].trim().contains("NA")){
                  custompojo.setCarrierDelay(0);  
                }
                else {
                custompojo.setLateAircraftDelay(Integer.parseInt(token[28]));
                }*/
                if (!(token[24].trim().contains("NA"))){
                    custompojo.setCarrierDelay(Integer.parseInt(token[24]));
                }
                 if (!(token[25].trim().contains("NA"))){
                    custompojo.setWeatherDelay(Integer.parseInt(token[25]));
                }
                  if (!(token[26].trim().contains("NA"))){
                    custompojo.setNasDelay(Integer.parseInt(token[26]));
                }
                   if (!(token[27].trim().contains("NA"))){
                    custompojo.setSecurityDelay(Integer.parseInt(token[27]));
                }
                    if (!(token[28].trim().contains("NA"))){
                    custompojo.setLateAircraftDelay(Integer.parseInt(token[28]));
                }
                
                context.write(origin, custompojo);

            }
        }

    }

    public static class DelayReducer extends Reducer<Text, DelaysPojo, Text, Text> {

        private Text result = new Text();
// private Set<String> dist = new HashSet<String>();
        private List<String> dist = new ArrayList<String>();

        @Override
        protected void reduce(Text key, Iterable<DelaysPojo> values, Context context) throws IOException, InterruptedException {

            int carrierDelayTotal = 0;
            int weatherDelayTotal = 0;
            int nasDelayTotal = 0;
            int securityDelayTotal = 0;
            int lateAircraftDelayTotal = 0;

            for (DelaysPojo val : values) {
                carrierDelayTotal = val.getCarrierDelay() + carrierDelayTotal;
                weatherDelayTotal = val.getWeatherDelay() + weatherDelayTotal;
                nasDelayTotal = val.getNasDelay() + nasDelayTotal;
                securityDelayTotal = val.getSecurityDelay() + securityDelayTotal;
                lateAircraftDelayTotal = val.getLateAircraftDelay() + lateAircraftDelayTotal;
            }

            dist.add(0, String.valueOf(carrierDelayTotal));
            dist.add(1, String.valueOf(weatherDelayTotal));
            dist.add(2, String.valueOf(nasDelayTotal));
            dist.add(3, String.valueOf(securityDelayTotal));
            dist.add(4, String.valueOf(lateAircraftDelayTotal));
            

            int max = dist.indexOf(Collections.max(dist));
            String delay = "";
            if (max==0) {
                delay = "CarrierDelay " + dist.get(max);
            }
            if (max == 1) {
                delay = "WeatherDelay " + dist.get(max);
            }
            if (max == 2) {
                delay = "NASDelay " + dist.get(max);
            }
            if (max == 3) {
                delay = "SecurityDelayTotal " + dist.get(max);
            }
            if (max == 4) {
                delay = "LateAircraftDelayTotal " + dist.get(max);
            }
            result.set(delay);
            context.write(key, result);
            dist.clear();
        }

    }
}
