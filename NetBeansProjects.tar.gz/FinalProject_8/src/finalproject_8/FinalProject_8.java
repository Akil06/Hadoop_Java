/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_8;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/**
 *
 * @author akil
 */
public class FinalProject_8 {

    /**
     * @param args the command line arguments
     */
    public static int main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "join pattern");
        job.setJarByClass(FinalProject_8.class);
        job.setMapperClass(sourceMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(CustomPojo.class);
        job.setReducerClass(sourceReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(CustomPojo.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        // System.exit(job.waitForCompletion(true) ? 0 : 1);
        boolean success = job.waitForCompletion(true);
        // return success ? 0 : 2;

        Configuration conf2 = new Configuration();

        Job job2 = Job.getInstance(conf2, "Chaining");

        if (success) {
            job2.setJarByClass(FinalProject_8.class);
            MultipleInputs.addInputPath(job2, new Path(args[1]), TextInputFormat.class, JoinMapper1.class);
            MultipleInputs.addInputPath(job2, new Path(args[2]), TextInputFormat.class, JoinMapper2.class);
            job2.setReducerClass(JoinReducer.class);
            job2.setOutputFormatClass(TextOutputFormat.class);
            TextOutputFormat.setOutputPath(job2, new Path(args[3]));

            job2.setOutputKeyClass(Text.class);
            job2.setOutputValueClass(Text.class);

            System.exit(job2.waitForCompletion(true) ? 0 : 1);

        }
        return success ? 0 : 2;
    }

    public static class sourceMapper extends Mapper<Object, Text, Text, CustomPojo> {

        private Text source = new Text();
        private CustomPojo destinationPojo = new CustomPojo();

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            //super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.

            String input = new String(value.toString());
            String[] token = input.split(",");
            if (!token[0].trim().contains("Year")) {
                source.set(token[16]);
                destinationPojo.setDestination(token[17]);
                destinationPojo.setFlightNo(token[9]);
                context.write(source, destinationPojo);
            }

        }
    }

    public static class sourceReducer extends Reducer<Text, CustomPojo, Text, CustomPojo> {

        private CustomPojo result = new CustomPojo();
        private HashMap<String, String> destMap = new HashMap();

        @Override
        protected void reduce(Text key, Iterable<CustomPojo> values, Context context) throws IOException, InterruptedException {
            //  super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.

            String flightNo;
            String destination;

            String prev_destination = "";

            int count = 0;
            System.out.println("key" + key);
            //  System.out.println("airportName"+airportName);
            for (CustomPojo d : values) {
                //      distance = d.getDistance();
                destination = d.getDestination();
                flightNo = d.getFlightNo();
                destMap.put(flightNo, destination);
                //Collection val=destMap.values();

            }

            for (Map.Entry<String, String> entry : destMap.entrySet()) {
                result.setDestination(entry.getValue());
                result.setFlightNo(entry.getKey());
                context.write(key, result);
            }
        }

    }

    public static class JoinMapper1 extends Mapper<Object, Text, Text, Text> {

        private Text outKey = new Text();
        private Text outValue = new Text();

        public void map(Object key, Text value, Mapper.Context context) {
            try {
                String[] seperatedInput = value.toString().split("	");
                String source = seperatedInput[0].trim();

                if (source == null) {
                    return;
                }
                outKey.set(source);
                outValue.set("S" + value);
                context.write(outKey, outValue);
            } catch (IOException | InterruptedException ex) {
                Logger.getLogger(FinalProject_8.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static class JoinMapper2 extends Mapper<Object, Text, Text, Text> {

        private Text outKey = new Text();
        private Text outValue = new Text();

        public void map(Object key, Text value, Mapper.Context context) {
            try {

                String input = new String(value.toString());
                String[] token = input.split(",");
                if (!token[0].trim().contains("iata")) {

                    String code = token[0];
                    String name = token[1];
                   // if (code != " " && name != " ") {
                        //hm.put(key, value);
                        outKey.set(code);
                        outValue.set("B" + value);
                        context.write(outKey, outValue);
                    

                }
            } catch (IOException | InterruptedException ex) {
                Logger.getLogger(FinalProject_8.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    public static class JoinReducer extends Reducer<Text, Text, Text, Text> {

        private static final Text EMPTY_TEXT = new Text();
        private Text tmp = new Text();

        private ArrayList<Text> listA = new ArrayList<Text>();
        private ArrayList<Text> listB = new ArrayList<Text>();

        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            // super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.

            listA.clear();
            listB.clear();

            while (values.iterator().hasNext()) {

                tmp = values.iterator().next();

                if (tmp.charAt(0) == 'S') {
                    String[] seperatedInput = tmp.toString().split("	");
                    listA.add(new Text(seperatedInput[1] +" "+ seperatedInput[2]));
                } else if (tmp.charAt(0) == 'B') {
                    String[] seperatedInput = tmp.toString().split(",");
                    listB.add(new Text(seperatedInput[1]));
                    // listB.add(new Text(seperatedInput[1]));
                }
            }

            executeJoinLogic(context);
        }

        private void executeJoinLogic(Context context) {

            for (Text A : listA) {
                if (!listB.isEmpty()) {
                    for (Text B : listB) {
                        try {
                            context.write(A, B);
                        } catch (IOException | InterruptedException ex) {
                            Logger.getLogger(FinalProject_8.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                } else {
                    try {
                        context.write(A, EMPTY_TEXT);
                    } catch (IOException | InterruptedException ex) {
                        Logger.getLogger(FinalProject_8.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }

        }
    }
}
