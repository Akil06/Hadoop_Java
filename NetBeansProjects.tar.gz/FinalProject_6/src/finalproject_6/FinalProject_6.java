/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_6;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import java.util.List;
import org.apache.hadoop.conf.Configurable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author akil
 */
public class FinalProject_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        // TODO code application logic here
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Horiz1");
        job.setJarByClass(FinalProject_6.class);
        job.setMapperClass(DelayMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DelaysPojo.class);
        job.setReducerClass(DelayReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        // System.exit(job.waitForCompletion(true) ? 0 : 1);
         boolean success = job.waitForCompletion(true);
        // return success ? 0 : 2;

        Configuration conf2 = new Configuration();

        Job job2 = Job.getInstance(conf2, "Chaining");

        if (success) {

            job2.setJarByClass(FinalProject_6.class);
              job2.setMapperClass(partitionerMapper.class);
        job2.setMapOutputKeyClass(Text.class);
        job2.setMapOutputValueClass(Text.class);
        job2.setReducerClass(partionReducer.class);
        job2.setOutputKeyClass(Text.class);
        job2.setOutputValueClass(NullWritable.class);
        job2.setPartitionerClass(partionerDelay.class);
        job2.setNumReduceTasks(5);
        FileInputFormat.addInputPath(job2, new Path(args[1]));
        FileOutputFormat.setOutputPath(job2, new Path(args[2]));
         System.exit(job2.waitForCompletion(true) ? 0 : 2);

        }
    }

    public static class DelayMapper extends Mapper<Object, Text, Text, DelaysPojo> {

        private Text origin = new Text();

        static int count = 0;

        private DelaysPojo custompojo = new DelaysPojo();

        @Override
        protected void map(Object key, Text value, Mapper.Context context) throws IOException, InterruptedException {
            String input = new String(value.toString());
            String[] token = input.split(",");
            count++;

            if (!token[0].trim().contains("Year")) {

                origin.set(token[16]);

                if (!(token[24].trim().contains("NA"))) {
                    custompojo.setCarrierDelay(Integer.parseInt(token[24]));
                }
                if (!(token[25].trim().contains("NA"))) {
                    custompojo.setWeatherDelay(Integer.parseInt(token[25]));
                }
                if (!(token[26].trim().contains("NA"))) {
                    custompojo.setNasDelay(Integer.parseInt(token[26]));
                }
                if (!(token[27].trim().contains("NA"))) {
                    custompojo.setSecurityDelay(Integer.parseInt(token[27]));
                }
                if (!(token[28].trim().contains("NA"))) {
                    custompojo.setLateAircraftDelay(Integer.parseInt(token[28]));
                }

                context.write(origin, custompojo);

            }
        }

    }

    public static class DelayReducer extends Reducer<Text, DelaysPojo, Text, Text> {

        private Text result = new Text();
// private Set<String> dist = new HashSet<String>();
        private List<String> dist = new ArrayList<String>();

        @Override
        protected void reduce(Text key, Iterable<DelaysPojo> values, Context context) throws IOException, InterruptedException {

            int carrierDelayTotal = 0;
            int weatherDelayTotal = 0;
            int nasDelayTotal = 0;
            int securityDelayTotal = 0;
            int lateAircraftDelayTotal = 0;

            for (DelaysPojo val : values) {
                carrierDelayTotal = val.getCarrierDelay() + carrierDelayTotal;
                weatherDelayTotal = val.getWeatherDelay() + weatherDelayTotal;
                nasDelayTotal = val.getNasDelay() + nasDelayTotal;
                securityDelayTotal = val.getSecurityDelay() + securityDelayTotal;
                lateAircraftDelayTotal = val.getLateAircraftDelay() + lateAircraftDelayTotal;
            }

            dist.add(0, String.valueOf(carrierDelayTotal));
            dist.add(1, String.valueOf(weatherDelayTotal));
            dist.add(2, String.valueOf(nasDelayTotal));
            dist.add(3, String.valueOf(securityDelayTotal));
            dist.add(4, String.valueOf(lateAircraftDelayTotal));

            int max = dist.indexOf(Collections.max(dist));
            String delay = "";
            if (max == 0) {
                delay = "CarrierDelay";
            }
            if (max == 1) {
                delay = "WeatherDelay";
            }
            if (max == 2) {
                delay = "NASDelay";
            }
            if (max == 3) {
                delay = "SecurityDelay";
            }
            if (max == 4) {
                delay = "LateAircraftDelay";
            }
            result.set(delay);
            context.write(key, result);
            dist.clear();
        }

    }

    public static class partitionerMapper extends Mapper<LongWritable, Text, Text, Text> {

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            //  super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.

            String input = new String(value.toString());
            String[] token = input.split("\\t");

            context.write(new Text(token[1]), new Text(token[0]));
        }

    }

    public static class partionerDelay extends Partitioner<Text, Text> {

        @Override
        public int getPartition(Text key, Text value, int NumOfReduceTask) {
            String input = new String(value.toString());
            String[] token = input.split("\\t");

            if (key.equals(new Text("CarrierDelay"))) {
                return 0;
            }
            if (key.equals(new Text("WeatherDelay"))) {
                return 1;
            }
            if (key.equals(new Text("NASDelay"))) {
                return 2;
            }
            if (key.equals(new Text("SecurityDelay"))) {
                return 3;
            }
            //         if(key.equals(new Text("LateAircraftDelay"))){
            return 4;
        }
    }

    public static class partionReducer extends Reducer<Text, Text, Text, NullWritable> {

        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            for (Text t : values) {
                context.write(t, NullWritable.get());
            }
        }
    }
}
