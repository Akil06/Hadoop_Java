/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_4;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import java.util.List;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author akil
 */
public class FinalProject_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        // TODO code application logic here
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Horiz1");
        job.setJarByClass(FinalProject_4.class);
        job.setMapperClass(DelayMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DelaysPojo.class);
        job.setReducerClass(DelayReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

    public static class DelayMapper extends Mapper<Object, Text, Text, DelaysPojo> {

        private Text origin = new Text();

        static int count = 0;

        private DelaysPojo custompojo = new DelaysPojo();

        @Override
        protected void map(Object key, Text value, Mapper.Context context) throws IOException, InterruptedException {
            String input = new String(value.toString());
            String[] token = input.split(",");
            count++;

            if (!token[0].trim().contains("Year")) {

                origin.set(token[16]);

                if (!(token[24].trim().contains("NA"))) {
                    custompojo.setCarrierDelay(Integer.parseInt(token[24]));
                }
                if (!(token[25].trim().contains("NA"))) {
                    custompojo.setWeatherDelay(Integer.parseInt(token[25]));
                }
                if (!(token[26].trim().contains("NA"))) {
                    custompojo.setNasDelay(Integer.parseInt(token[26]));
                }
                if (!(token[27].trim().contains("NA"))) {
                    custompojo.setSecurityDelay(Integer.parseInt(token[27]));
                }
                if (!(token[28].trim().contains("NA"))) {
                    custompojo.setLateAircraftDelay(Integer.parseInt(token[28]));
                }

                context.write(origin, custompojo);

            }
        }

    }

    public static class DelayReducer extends Reducer<Text, DelaysPojo, Text, DoubleWritable> {

        private DoubleWritable result = new DoubleWritable();


        @Override
        protected void reduce(Text key, Iterable<DelaysPojo> values, Context context) throws IOException, InterruptedException {

            int carrierDelayTotal = 0;
            int weatherDelayTotal = 0;
            int nasDelayTotal = 0;
            int securityDelayTotal = 0;
            int lateAircraftDelayTotal = 0;
            int totalDelay = 0;
            int count = 0;
            for (DelaysPojo val : values) {
                //carrierDelayTotal = val.getCarrierDelay() + carrierDelayTotal;
                if (val.getCarrierDelay() > 0) {
                    carrierDelayTotal++;
                }
                if (val.getWeatherDelay() > 0) {
                    weatherDelayTotal++;
                }
                //weatherDelayTotal = val.getWeatherDelay() + weatherDelayTotal;
                if (val.getNasDelay() > 0) {
                    nasDelayTotal++;
                    //nasDelayTotal = val.getNasDelay() + nasDelayTotal;
                }

                if (val.getSecurityDelay() > 0) {
                    securityDelayTotal++;
                }
                //securityDelayTotal = val.getSecurityDelay() + securityDelayTotal;
                if (val.getLateAircraftDelay() > 0) {
                    lateAircraftDelayTotal++;
                    //lateAircraftDelayTotal = val.getLateAircraftDelay() + lateAircraftDelayTotal;
                }
               

                count++;
            }
             totalDelay = totalDelay + carrierDelayTotal + weatherDelayTotal + nasDelayTotal + securityDelayTotal + lateAircraftDelayTotal;

    
            double frequency =  (double)totalDelay / (count );
            System.out.println("key "+key);
            System.out.println("count "+count);
            System.out.println("totalDelay "+totalDelay);
            result.set(frequency);
            context.write(key, result);
            
        }

    }

}
