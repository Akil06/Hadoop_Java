/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_5;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

/**
 *
 * @author akil
 */
public class DestinationDistPojo implements Writable /*, WritableComparable<DestinationDistPojo> */{
    
  //  String source;
    String destination;
    Integer distance;

    /*public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }
    */
    

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }
    
    
    

    @Override
    public void write(DataOutput d) throws IOException {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        d.writeUTF(destination);
        d.writeInt(distance);
      //  d.writeUTF(source);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        destination = di.readUTF();
        distance = di.readInt();
       // source=di.readUTF();
        
    }
    
    @Override
     public String toString()
    {
        // return (new StringBuilder().append(max_stock).append("\t").append(date_maxStock).append("\t").append(min_stock).append("\t").append(date_minStock).append("\t").append(adj).toString());
    return (new StringBuilder().append(destination ).append("\t").append(distance).toString());
    }

   /*@Override
    public int compareTo(DestinationDistPojo o) {
  //      throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  
  int result = source.compareTo(o.source);
        if(result ==0)
        {
            result = destination.compareTo(o.destination);
           
        }
        else {
            result=(1)*result;
        }
        return result;
    }*/
    }


