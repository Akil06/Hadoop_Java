package finalproject_7;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;

/**
 *
 * @author akil
 */
public class DelaysPojo implements Writable{
    
    Integer carrierDelay;
    Integer weatherDelay;
    Integer nasDelay;
    Integer securityDelay;
    Integer lateAircraftDelay;

    public DelaysPojo() {
        carrierDelay=0;
     weatherDelay=0;
     nasDelay=0;
     securityDelay=0;
     lateAircraftDelay=0;
        
    }

    public Integer getCarrierDelay() {
        return carrierDelay;
    }

    public void setCarrierDelay(Integer carrierDelay) {
        this.carrierDelay = carrierDelay;
    }

    public Integer getWeatherDelay() {
        return weatherDelay;
    }

    public void setWeatherDelay(Integer weatherDelay) {
        this.weatherDelay = weatherDelay;
    }

    public Integer getNasDelay() {
        return nasDelay;
    }

    public void setNasDelay(Integer nasDelay) {
        this.nasDelay = nasDelay;
    }

    public Integer getSecurityDelay() {
        return securityDelay;
    }

    public void setSecurityDelay(Integer securityDelay) {
        this.securityDelay = securityDelay;
    }

    public Integer getLateAircraftDelay() {
        return lateAircraftDelay;
    }

    public void setLateAircraftDelay(Integer lateAircraftDelay) {
        this.lateAircraftDelay = lateAircraftDelay;
    }

    @Override
    public void write(DataOutput d) throws IOException {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
   d.writeInt(carrierDelay);
   d.writeInt(weatherDelay);
   d.writeInt(nasDelay);
   d.writeInt(securityDelay);
   d.writeInt(lateAircraftDelay);
    }

    @Override
    public void readFields(DataInput di) throws IOException {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        carrierDelay=di.readInt();
     weatherDelay=di.readInt();
     nasDelay=di.readInt();
     securityDelay=di.readInt();
     lateAircraftDelay=di.readInt();
    }
    
    @Override
     public String toString()
    {
        // return (new StringBuilder().append(max_stock).append("\t").append(date_maxStock).append("\t").append(min_stock).append("\t").append(date_minStock).append("\t").append(adj).toString());
    return (new StringBuilder().append(carrierDelay).append("\t").append(weatherDelay).append("\t").append(nasDelay).append("\t").append(securityDelay).append("\t").append(lateAircraftDelay).toString());
    }
    
    
}
