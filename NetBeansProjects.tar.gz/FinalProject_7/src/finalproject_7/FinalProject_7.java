/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_7;

import java.io.IOException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import java.util.List;
import java.util.TreeMap;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;

import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 *
 * @author akil
 */
public class FinalProject_7 {

    /**
     * @param args the command line arguments
     */
    public static int main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        // TODO code application logic here
          Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "top 10");
        job.setJarByClass(FinalProject_7.class);
        job.setMapperClass(DelayMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DelaysPojo.class);
        job.setReducerClass(DelayReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
       // System.exit(job.waitForCompletion(true) ? 0 : 1);
         boolean success = job.waitForCompletion(true);
        // return success ? 0 : 2;

        Configuration conf2 = new Configuration();

        Job job2 = Job.getInstance(conf2, "Chaining");

        if (success) {

            job2.setJarByClass(FinalProject_7.class);
              job2.setMapperClass(topTenMapper.class);
        job2.setMapOutputKeyClass(NullWritable.class);
        job2.setMapOutputValueClass(Text.class);
        job2.setReducerClass(topTenReducer.class);
        job2.setOutputKeyClass(NullWritable.class);
        job2.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job2, new Path(args[1]));
        FileOutputFormat.setOutputPath(job2, new Path(args[2]));
         System.exit(job2.waitForCompletion(true) ? 0 : 1);

        }
        return success ? 0 : 2;
    }

    public static class DelayMapper extends Mapper<Object, Text, Text, DelaysPojo> {

        private Text origin = new Text();

        static int count = 0;

        private DelaysPojo custompojo = new DelaysPojo();

        @Override
        protected void map(Object key, Text value, Mapper.Context context) throws IOException, InterruptedException {
            String input = new String(value.toString());
            String[] token = input.split(",");
            count++;

            if (!token[0].trim().contains("Year")) {

                origin.set(token[16]);

                if (!(token[24].trim().contains("NA"))) {
                    custompojo.setCarrierDelay(Integer.parseInt(token[24]));
                }
                if (!(token[25].trim().contains("NA"))) {
                    custompojo.setWeatherDelay(Integer.parseInt(token[25]));
                }
                if (!(token[26].trim().contains("NA"))) {
                    custompojo.setNasDelay(Integer.parseInt(token[26]));
                }
                if (!(token[27].trim().contains("NA"))) {
                    custompojo.setSecurityDelay(Integer.parseInt(token[27]));
                }
                if (!(token[28].trim().contains("NA"))) {
                    custompojo.setLateAircraftDelay(Integer.parseInt(token[28]));
                }

                context.write(origin, custompojo);

            }
        }

    }

    public static class DelayReducer extends Reducer<Text, DelaysPojo, Text, IntWritable> {

        private DoubleWritable result = new DoubleWritable();

        @Override
        protected void reduce(Text key, Iterable<DelaysPojo> values, Context context) throws IOException, InterruptedException {

            int carrierDelayTotal = 0;
            int weatherDelayTotal = 0;
            int nasDelayTotal = 0;
            int securityDelayTotal = 0;
            int lateAircraftDelayTotal = 0;
            int totalDelay = 0;
            int count = 0;
            for (DelaysPojo val : values) {
                //carrierDelayTotal = val.getCarrierDelay() + carrierDelayTotal;
                if (val.getCarrierDelay() > 0) {
                    carrierDelayTotal++;
                }
                if (val.getWeatherDelay() > 0) {
                    weatherDelayTotal++;
                }
                //weatherDelayTotal = val.getWeatherDelay() + weatherDelayTotal;
                if (val.getNasDelay() > 0) {
                    nasDelayTotal++;
                    //nasDelayTotal = val.getNasDelay() + nasDelayTotal;
                }

                if (val.getSecurityDelay() > 0) {
                    securityDelayTotal++;
                }
                //securityDelayTotal = val.getSecurityDelay() + securityDelayTotal;
                if (val.getLateAircraftDelay() > 0) {
                    lateAircraftDelayTotal++;
                    //lateAircraftDelayTotal = val.getLateAircraftDelay() + lateAircraftDelayTotal;
                }

                count++;
            }
            totalDelay = totalDelay + carrierDelayTotal + weatherDelayTotal + nasDelayTotal + securityDelayTotal + lateAircraftDelayTotal;

            double frequency = (double) totalDelay / (count);
          //  System.out.println("key " + key);
           // System.out.println("count " + count);
            // System.out.println("totalDelay " + totalDelay);
           // result.set(frequency);
            context.write(key, new IntWritable(totalDelay));

        }

    }

    public static class topTenMapper extends Mapper<LongWritable, Text, NullWritable, Text> {

        private TreeMap<Integer, Text> delaySourceMap = new TreeMap<Integer, Text>();

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            //  super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.

            String input = new String(value.toString());
            String[] token = input.split("	");
            delaySourceMap.put(Integer.parseInt(token[1]), new Text(input));

            if (delaySourceMap.size() > 10) {
                delaySourceMap.remove(delaySourceMap.firstKey());
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            //    super.cleanup(context); //To change body of generated methods, choose Tools | Templates.
            for (Text t : delaySourceMap.values()) {
                context.write(NullWritable.get(), t);
            }
        }
    }

    public static class topTenReducer extends Reducer<NullWritable, Text, NullWritable, Text> {

        private TreeMap<Integer, Text> delaySourceMapRed = new TreeMap<Integer, Text>();

        @Override
        protected void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            //super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            for (Text value : values) {
                String input = new String(value.toString());
                String[] token = input.split("	");
                delaySourceMapRed.put(Integer.parseInt(token[1]), new Text(input));

                if (delaySourceMapRed.size() > 10) {
                    delaySourceMapRed.remove(delaySourceMapRed.firstKey());
                }
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            // super.cleanup(context); //To change body of generated methods, choose Tools | Templates.
            for (Text t : delaySourceMapRed.descendingMap().values()) {
                context.write(NullWritable.get(), t);
            }
        }

    }
}
