/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_9;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.apache.hadoop.fs.Path;

/**
 *
 * @author akil
 */
public class LookupPojoParcer {
    String airPortCode;
    String airportName;
    private HashMap<String,String> hm = new HashMap<String,String>();
	public String getStationName(String input)
	{
	    // Get a set of the entries
	 /*   Set set = hm.entrySet();
	    // Get an iterator
	    Iterator itr = set.iterator();
	    // Get the key,value for an elements in the HashMap
	    while(itr.hasNext()) 
	    {	    	
                */
                for (Map.Entry<String, String> entry : hm.entrySet()) {
	    // Map.Entry<String,String> me = (Map.Entry)itr.next();
            airPortCode = entry.getKey();
           // System.out.println("key in"+input);
            //System.out.println("key map"+entry.getKey());
            //System.out.println("value map"+entry.getValue());
	         if (airPortCode.contains(input)) 
	         {
                     // System.out.println("key for"+entry.getKey());
	        	airportName = entry.getValue();
	        	break;
	         }
                }
	    //}		
		return airportName;
	}
	public void initialize(File path) throws IOException
	{
		FileReader fr = new FileReader(path.toString());
		BufferedReader buff = new BufferedReader(fr);
		while((airPortCode = buff.readLine()) != null)
		{
                    
			String s[] =airPortCode.split(",");
                        if (!s[0].trim().contains("iata")) {
                            
			String key = s[0];
			String value = s[1];
				if (key !=" " && value != " "){
					hm.put(key, value);
				}			
		}		
} 
        }
}
