/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_9;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import com.google.common.base.Charsets;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnel;
import com.google.common.hash.Sink;
import java.io.BufferedReader;
import java.io.FileReader;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.io.NullWritable;
/**
 *
 * @author akil
 */
public class FinalProject_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException, ClassNotFoundException {
        // TODO code application logic here

        Configuration conf1 = new Configuration();
        Job job1 = Job.getInstance(conf1, "distinct chaning");
        job1.setJarByClass(FinalProject_9.class);
        job1.setMapperClass(delayMapper.class);
        job1.setMapOutputKeyClass(Text.class);
        job1.setMapOutputValueClass(DestinationDelayPojo.class);
        DistributedCache.addCacheFile(new URI(args[2]), job1.getConfiguration());
        job1.setReducerClass(delayReducer.class);
        job1.setOutputKeyClass(Text.class);
        job1.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job1, new Path(args[0]));
        FileOutputFormat.setOutputPath(job1, new Path(args[1]));

      //  System.exit(job1.waitForCompletion(true) ? 0 : 1);
 boolean success = job1.waitForCompletion(true);
        // return success ? 0 : 2;

        Configuration conf2 = new Configuration();

        Job job2 = Job.getInstance(conf2, "Filter");

        if (success) {
            job2.setJarByClass(FinalProject_9.class);
    
        job2.setMapperClass(BloomFilterMapper.class);
        job2.setMapOutputKeyClass(Text.class);
        job2.setMapOutputValueClass(NullWritable.class);

        //adding the file in the cache having the Person class records
        //job.addCacheFile(new Path("localhost:9000/bhavesh/LabAssignment/CacheInput/cache.txt").toUri());
        DistributedCache.addCacheFile(new URI(args[4]), job2.getConfiguration());
        job2.setNumReduceTasks(0);

        FileInputFormat.addInputPath(job2, new Path(args[1]));
        FileOutputFormat.setOutputPath(job2, new Path(args[3]));

        job2.waitForCompletion(true);       
    }
    }

    public static class delayMapper extends Mapper<Object, Text, Text, DestinationDelayPojo> {

        private Text source = new Text();
        private DestinationDelayPojo delaypojo = new DestinationDelayPojo();

        @Override
        protected void map(Object key, Text value, Mapper.Context context) throws IOException, InterruptedException {
            // super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.

            String input = new String(value.toString());
            String[] token = input.split(",");
            if (!token[0].trim().contains("Year")) {
                source.set(token[16]);
                if (token[15].isEmpty()) {
                    token[15] = "0";
                }
                if (token[14].isEmpty()) {
                    token[14] = "0";
                }
                delaypojo.setDepartureDelay(Double.parseDouble(token[15]));
                delaypojo.setArrivalDelay(Double.parseDouble(token[14]));

                //  System.out.println("source"+token[16]);
                //System.out.println("row"+token[7]+" "+token[8] + " "+ token[9] +" "+ token[10]+ " "+token[17]);
                context.write(source, delaypojo);
            }
        }

    }

    public static class delayReducer extends Reducer<Text, DestinationDelayPojo, Text, Text> {

        private Text result = new Text();
        private HashMap<String, Integer> destMap = new HashMap();

        private LookupPojoParcer metadata;

        String fileName;
        String airportName;
        String destinationAirportName;

        protected void setup(Context context) throws IOException {
            try {
                Path[] localFiles = DistributedCache.getLocalCacheFiles(context.getConfiguration());
                for (Path eachPath : localFiles) {
                    // fileName = eachPath.getName().toString().trim();
                    //if (fileName.equals("airports.csv")) {
                    File myFile = new File(eachPath.toUri());
                    //  BufferedReader bufferedReader = new BufferedReader(new FileReader(myFile.toString()));
                    metadata = new LookupPojoParcer();
                    metadata.initialize(myFile);
                    break;
                    //}
                }
                System.out.println("File : " + localFiles[0].toString());
            } catch (NullPointerException e) {
                System.out.println("Exception : " + e);
            }

            System.out.println("Cache : " + context.getConfiguration().get("mapred.cache.files"));
        }

        @Override
        protected void reduce(Text key, Iterable<DestinationDelayPojo> values, Context context) throws IOException, InterruptedException {
            // super.reduce(key, values, context); //To change body of generated methods, choose Tools | Templates.
            String airportName = metadata.getStationName(key.toString());
            int arrivalDelayCount = 0;
            int departDelayCount = 0;

            Double arrivalDelay = 0.0;
            Double departDelay = 0.0;

            for (DestinationDelayPojo d : values) {
                //arrivalDelay = d.arrivalDelay;
                //departDelay = d.departureDelay;
                int arrret = d.arrivalDelay.compareTo(0.0);
                if (arrret <= 0) {
                    arrivalDelayCount++;
                }
                int delret = d.departureDelay.compareTo(0.0);

                if (delret <= 0) {
                    departDelayCount++;
                }
            }
            String s = arrivalDelayCount + "	" + departDelayCount;
            context.write(new Text(airportName), new Text(s));
        }

    }
    
    public static class BloomFilterMapper extends Mapper<Object, Text, Text, NullWritable> {

        Funnel<FilterPojo> p = new Funnel<FilterPojo>() {

            @Override
            public void funnel(FilterPojo t, Sink sink) {
          //      throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
           sink.putString(t.source).putInt(t.arrivalDelay)
                        .putInt(t.departDelay); }
        };
    
    private BloomFilter<FilterPojo> best = BloomFilter.create(p, 500, 0.01);

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
        //    super.setup(context); //To change body of generated methods, choose Tools | Templates.
        
         String source;
    int arrivalDelay;
     int departDelay;
       try {
                Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());
                if (files != null && files.length > 0) {

                    for (Path file : files) {

                        try {
                            File myFile = new File(file.toUri());
                            BufferedReader bufferedReader = new BufferedReader(new FileReader(myFile.toString()));
                            String line = null;
                            while ((line = bufferedReader.readLine()) != null) {
                                String[] split = line.split(",");

                                source = String.valueOf(split[0]);
                                arrivalDelay = Integer.parseInt(split[1]);
                                departDelay = Integer.parseInt(split[2]);
                               
                                FilterPojo ft = new FilterPojo(source, arrivalDelay, departDelay);
                                best.put(ft);
                            }
                        } catch (IOException ex) {
                            System.err.println("Exception while reading  file: " + ex.getMessage());
                        }
                    }
                }
            } catch (IOException ex) {
                System.err.println("Exception in mapper setup: " + ex.getMessage());
            }

        }

    
    
    
    
    
        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            // super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            
            String values[] = value.toString().split("	");
             FilterPojo ft = new FilterPojo(values[0].toString(), Integer.parseInt(values[1]), Integer.parseInt(values[2]));
            //Person p = new Person(Integer.parseInt(values[0]), values[1], values[2], Integer.parseInt(values[3]));
            if (best.mightContain(ft)) {
                context.write(value, NullWritable.get());
            }
        }
    
    
    
}
}