/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_9;

/**
 *
 * @author akil
 */
public class FilterPojo {
    
    final String source;
   final Integer arrivalDelay;
    final Integer departDelay;

    public FilterPojo(String source, Integer arrivalDelay, Integer departDelay) {
        this.source = source;
        this.arrivalDelay = arrivalDelay;
        this.departDelay = departDelay;
    }
}
