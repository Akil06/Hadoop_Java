/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject_3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/**
 *
 * @author akil
 */
public class FinalProject_3 {

    /**
     * @param args the command line arguments
     */
    public static int main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {
        // TODO code application logic here

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Monthwise Delay");
        job.setJarByClass(FinalProject_3.class);
        job.setMapperClass(MonnthlyDelayMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(CancelledFlightsPojo.class);
        job.setReducerClass(MonnthlyDelayReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        // System.exit(job.waitForCompletion(true) ? 0 : 1);
        boolean success = job.waitForCompletion(true);
        // return success ? 0 : 2;

        Configuration conf2 = new Configuration();

        Job job2 = Job.getInstance(conf2, "Month wise binning output");

        if (success) {
            job2.setJarByClass(FinalProject_3.class);
            MultipleOutputs.addNamedOutput(job2, "bins", TextOutputFormat.class, Text.class, NullWritable.class);
            MultipleOutputs.setCountersEnabled(job2, true);
            job2.setMapperClass(MonnthlyDelayMapper2.class);

            job2.setNumReduceTasks(0);
            FileInputFormat.addInputPath(job2, new Path(args[1]));
            FileOutputFormat.setOutputPath(job2, new Path(args[2]));
            System.exit(job2.waitForCompletion(true) ? 0 : 2);
        }
          return success ? 0 : 2;
    }

    public static class MonnthlyDelayMapper2 extends Mapper<Object, Text, Text, NullWritable> {

        private MultipleOutputs<Text, NullWritable> mos = null;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            mos = new MultipleOutputs(context); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            // super.map(key, value, context); //To change body of generated methods, choose Tools | Templates.
            //String input = new String(value.toString());
            String[] token = value.toString().split("\\t");

            String month = token[0];
            //for (int i = 0; i < 12; i++) {

            mos.write("bins", value, NullWritable.get(), month);

            //}
            //To change body of generated methods, choose Tools | Templates.
        }
    }

    public static class MonnthlyDelayMapper extends Mapper<Object, Text, Text, CancelledFlightsPojo> {

        private CancelledFlightsPojo custompojo = new CancelledFlightsPojo();
        private Text source = new Text();

        @Override
        protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String input = new String(value.toString());
            String[] token = input.split(",");
            if (!token[0].trim().contains("Year")) {
                source.set(token[1]);
                custompojo.setFlightNo(Integer.parseInt(token[9]));
                //custompojo.setMonth(Integer.parseInt(token[1]));
                custompojo.setSource(token[16]);
                custompojo.setDestination(token[17]);
                custompojo.setCancellationCode(token[22]);
                if (token[21].equalsIgnoreCase("1"))
                context.write(source, custompojo);
            }
        }
    }

    public static class MonnthlyDelayReducer extends Reducer<Text, CancelledFlightsPojo, Text, Text> {

        private Text result = new Text();


        @Override
        protected void reduce(Text key, Iterable<CancelledFlightsPojo> values, Context context) throws IOException, InterruptedException {

            Integer flightNo;
            Integer month;
            String source;
            String destination;
            String cancellationCode;
            int delayCountA = 0;
            int delayCountB = 0;
            int delayCountC = 0;
            for (CancelledFlightsPojo val : values) {
                flightNo = val.getFlightNo();
                month = val.getMonth();
                source = val.getSource();
                destination = val.getDestination();
                cancellationCode = val.getCancellationCode();
                String cancelledFlightDetails = "";
                String canCodeDes = "";
                if (cancellationCode.matches("A")) {
                    canCodeDes = "Carrier Delay";
                }
                if (cancellationCode .contains("B")) {
                    canCodeDes = "Weather Delay";
                }
                if (cancellationCode.contains("C")) {
                    canCodeDes = "NAS Delay";
                }
                if (cancellationCode == "D") {
                    canCodeDes = "Weather Delay";
                }
                cancelledFlightDetails = source + " "+ flightNo + " " + destination + " " + canCodeDes;
                result.set(cancelledFlightDetails);
                context.write(key, result);
            }
        }

    }

}
